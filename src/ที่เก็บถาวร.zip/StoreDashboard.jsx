import React from "react";
import {
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer,
  LineChart, Line, CartesianGrid
} from "recharts";
import { FiDownload } from "react-icons/fi";
import "./StoreDashboard.css";
import { useParams } from "react-router-dom";

export default function StoreDashboard() {

  const { storeId } = useParams();
  console.log("Store ID:", storeId);
  // Data สำหรับ Dashboard
  const data = [
    { name: "เพ้นท์เล็บเจล", value: 32 },
    { name: "ต่อเล็บ", value: 28 },
    { name: "สปาเท้า", value: 25 },
    { name: "มาส์กมือ", value: 21 },
    { name: "เพ้นท์ลายตามสั่ง", value: 20 },
  ];

  const bookings = [
    { name: "สมหญิง ใจดี", time: "10:00 น.", status: "ยืนยันแล้ว" },
    { name: "วิโรจ สวยงาม", time: "11:30 น.", status: "รอยืนยัน" },
    { name: "นภา รักสวย", time: "13:00 น.", status: "ยืนยันแล้ว" },
    { name: "ปรียา หมั่นมี", time: "14:30 น.", status: "เสร็จสิ้น" },
  ];

  const alerts = [
    { text: "มีการจองใหม่จาก วิโรจ สวยงาม", time: "5 นาทีที่แล้ว" },
    { text: "ได้รับการชำระเงิน 8850 จากคุณสมหญิง", time: "15 นาทีที่แล้ว" },
    { text: "รีวิวใหม่ 5 ดาว จากคุณนภา", time: "1 ชั่วโมงที่แล้ว" },
  ];

  // Data สำหรับ Report (สมมติเพื่อใช้กับ Recharts)
  const incomeTrend = [
    { month: "ม.ค.", income: 878000 },
    { month: "ก.พ.", income: 920000 },
    { month: "มี.ค.", income: 850000 },
    { month: "เม.ย.", income: 980000 },
  ];

  return (
    <div className="admin-root report-page">
      <main className="dashboard report">
        {/* ===== ส่วนที่ 1: Header รายงานร้าน ===== */}
        <div className="header">
          <div>
            <h1>รายงานร้าน & แดชบอร์ด</h1>
            <p className="subtitle">สรุปภาพรวมและข้อมูลสถิติวันนี้</p>
          </div>
          <div className="actions">
            <select>
              <option>รายเดือน</option>
              <option>รายไตรมาส</option>
              <option>รายปี</option>
            </select>
            <button className="btn-export"><FiDownload /> Excel</button>
            <button className="btn-export"><FiDownload /> PDF</button>
          </div>
        </div>

        {/* ===== ส่วนที่ 2: Stats Cards (จาก Dashboard) ===== */}
        <div className="stats-grid">
          <div className="card">
            <p className="label">ยอดจองวันนี้</p>
            <h2>24</h2>
            <span className="trend up">↑ +12% จากเมื่อวาน</span>
          </div>
          <div className="card">
            <p className="label">รายได้วันนี้</p>
            <h2>฿18,450</h2>
            <span className="trend up">↑ +8% จากเมื่อวาน</span>
          </div>
          <div className="card">
            <p className="label">รีวิวเฉลี่ย</p>
            <h2>4.8</h2>
            <span>จาก 156 รีวิว</span>
          </div>
          <div className="card">
            <p className="label">ลูกค้าใหม่เดือนนี้</p>
            <h2>32</h2>
            <span className="trend up">↑ +18% จากเดือนที่แล้ว</span>
          </div>
        </div>

        {/* ===== ส่วนที่ 3: กราฟรายได้ (จาก Report) ===== */}
        <section className="chart-section card">
          <h3>รายได้รายเดือน</h3>
          <div className="chart-box">
             <ResponsiveContainer width="100%" height={350}>
                <LineChart data={incomeTrend}>
                  <CartesianGrid strokeDasharray="3 3" vertical={false} />
                  <XAxis dataKey="month" />
                  <YAxis />
                  <Tooltip />
                  <Line type="monotone" dataKey="income" stroke="#ff6b98" strokeWidth={3} dot={{ r: 6 }} />
                </LineChart>
             </ResponsiveContainer>
          </div>
        </section>

        {/* ===== ส่วนที่ 4: Grid ตาราง (รวมของเดิม) ===== */}
        <div className="grid-2">
          {/* บริการยอดนิยม (Bar Chart) */}
          <div className="card full">
            <h3>บริการยอดนิยม (Top 5 Services)</h3>
            <ResponsiveContainer width="100%" height={240}>
              <BarChart data={data}>
                <XAxis dataKey="name" />
                <YAxis />
                <Tooltip />
                <Bar dataKey="value" fill="#ff6b98" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>

          {/* การจองล่าสุด */}
          <div className="card">
            <h3>การจองล่าสุด</h3>
            <table className="booking-table">
              <thead>
                <tr>
                  <th>ชื่อ</th>
                  <th>เวลา</th>
                  <th>สถานะ</th>
                </tr>
              </thead>
              <tbody>
                {bookings.map((b, i) => (
                  <tr key={i}>
                    <td>{b.name}</td>
                    <td>{b.time}</td>
                    <td>
                      <span className={`status ${b.status === "ยืนยันแล้ว" ? "confirmed" : b.status === "รอยืนยัน" ? "pending" : "done"}`}>
                        {b.status}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* ===== ส่วนที่ 5: ตารางบริการ + พนักงาน (จาก Report) ===== */}
        <div className="table-row">
          <div className="table-card card">
            <h3>บริการที่ขายดี</h3>
            <table>
              <thead>
                <tr><th>บริการ</th><th>ยอดขาย</th><th>รายได้</th></tr>
              </thead>
              <tbody>
                <tr><td>เพ้นท์เล็บเจล</td><td>156</td><td>฿878,000</td></tr>
                <tr><td>ต่อเล็บอะคริลิค</td><td>98</td><td>฿878,400</td></tr>
                <tr><td>สปามือ</td><td>87</td><td>฿852,200</td></tr>
              </tbody>
            </table>
          </div>

          <div className="table-card card">
            <h3>พนักงานที่มียอดจองสูงสุด</h3>
            <table>
              <thead>
                <tr><th>พนักงาน</th><th>การจอง</th><th>คะแนน</th></tr>
              </thead>
              <tbody>
                <tr><td>วิภา ศิริมิช่วย</td><td>85</td><td>⭐ 4.9</td></tr>
                <tr><td>สุชา เส้นสวย</td><td>78</td><td>⭐ 4.8</td></tr>
              </tbody>
            </table>
          </div>
        </div>

        {/* ===== ส่วนที่ 6: การแจ้งเตือน ===== */}
        <div className="card alerts">
          <h3>การแจ้งเตือนจากระบบ</h3>
          <ul>
            {alerts.map((a, i) => (
              <li key={i}>
                <p>{a.text}</p>
                <span>{a.time}</span>
              </li>
            ))}
          </ul>
        </div>

        {/* Padding ท้ายหน้าเพื่อให้ Scroll พ้นขอบ */}
        <div style={{ height: "50px" }}></div>
      </main>
    </div>
  );
}