import React, { useState } from "react";
import "./StoreSettings.css";

export default function StoreSettings() {
  const [activeTab, setActiveTab] = useState("info");

  return (
    <main className="settings-page">
      <h1 className="title">การตั้งค่าร้าน</h1>
      <p className="subtitle">จัดการการตั้งค่าต่างๆ ของร้านของคุณ</p>

      {/* แถบเมนู */}
      <div className="tabs">
        <button
          className={activeTab === "info" ? "active" : ""}
          onClick={() => setActiveTab("info")}
        >
          ข้อมูลร้าน
        </button>
        <button
          className={activeTab === "team" ? "active" : ""}
          onClick={() => setActiveTab("team")}
        >
          ทีมงาน
        </button>
        <button
          className={activeTab === "payment" ? "active" : ""}
          onClick={() => setActiveTab("payment")}
        >
          การชำระเงิน
        </button>
        <button
          className={activeTab === "notify" ? "active" : ""}
          onClick={() => setActiveTab("notify")}
        >
          การแจ้งเตือน
        </button>
      </div>

      {/* ====== Content ====== */}
      <section className="tab-area">
        {/* ─── ข้อมูลร้าน ─── */}
        {activeTab === "info" && (
          <div className="card">
            <h3>ข้อมูลร้าน</h3>
            <div className="form-grid">
              <div className="col-1">
                <label>ชื่อร้าน</label>
                <input type="text" defaultValue="Nail Salon Pro" />

                <label>ที่อยู่</label>
                <textarea defaultValue="123/45 ถนนสุขุมวิท แขวงคลองเตย เขตคลองเตย กรุงเทพมหานคร 10110" />

                <label>คำอธิบายร้าน</label>
                <textarea defaultValue="ร้านทำเล็บคุณภาพ บริการด้วยใจ พนักงานมืออาชีพ" />
              </div>

              <div className="col-2">
                <label>หมายเลขโทรศัพท์</label>
                <input type="text" defaultValue="02-123-4567" />

                <label>อีเมล</label>
                <input type="text" defaultValue="info@nailsalon.com" />

                <div className="row">
                  <div>
                    <label>เวลาเปิด</label>
                    <input type="time" defaultValue="09:00" />
                  </div>
                  <div>
                    <label>เวลาปิด</label>
                    <input type="time" defaultValue="20:00" />
                  </div>
                </div>
              </div>
            </div>

            <div className="actions">
              <button className="btn-save">บันทึกการเปลี่ยนแปลง</button>
              <button className="btn-reset">รีเซ็ตค่าเริ่มต้น</button>
            </div>
          </div>
        )}

        {/* ─── ทีมงาน ─── */}
        {activeTab === "team" && (
          <div className="card">
            <h3>ทีมงาน</h3>
            <div className="team-list">
              {[
                { name: "วิภา ศิลป์สวย", email: "wipa@email.com", role: "Staff" },
                { name: "สุชา เส้นสวย", email: "suda@email.com", role: "Staff" },
                { name: "นิภา ดีไซน์", email: "nipa@email.com", role: "Manager" },
              ].map((member, i) => (
                <div className="team-item" key={i}>
                  <div>
                    <strong>{member.name}</strong>
                    <p>{member.email}</p>
                  </div>
                  <span className={`badge ${member.role === "Manager" ? "manager" : ""}`}>
                    {member.role}
                  </span>
                </div>
              ))}
              <button className="btn-add">+ เชิญพนักงานเข้าระบบ</button>
            </div>
          </div>
        )}

        {/* ─── การชำระเงิน ─── */}
        {activeTab === "payment" && (
          <div className="card">
            <h3>การชำระเงิน</h3>
            <div className="form-grid">
              <div className="col-1">
                <label>ธนาคาร</label>
                <select>
                  <option>ธนาคารไทยพาณิชย์</option>
                  <option>กสิกรไทย</option>
                  <option>กรุงไทย</option>
                </select>

                <label>ชื่อบัญชี</label>
                <input type="text" defaultValue="Nail Salon Pro" />

                <label>เลขบัญชี</label>
                <input type="text" defaultValue="123-4-56789-0" />

                <label>QR PromptPay</label>
                <input type="text" defaultValue="0812345678" />
              </div>

              <div className="col-2">
                <div className="switch-list">
                  <div className="switch-item">
                    <span>รับชำระเงินสด</span>
                    <label className="switch">
                      <input type="checkbox" defaultChecked />
                      <span className="slider"></span>
                    </label>
                  </div>
                  <div className="switch-item">
                    <span>รับบัตรเครดิต/เดบิต</span>
                    <label className="switch">
                      <input type="checkbox" defaultChecked />
                      <span className="slider"></span>
                    </label>
                  </div>
                </div>
              </div>
            </div>
            <div className="actions">
              <button className="btn-save">บันทึกการเปลี่ยนแปลง</button>
            </div>
          </div>
        )}

        {/* ─── การแจ้งเตือน ─── */}
        {activeTab === "notify" && (
          <div className="card">
            <h3>การแจ้งเตือน</h3>
            <div className="notify-list">
              {[
                "การแจ้งเตือนทางอีเมล",
                "การแจ้งเตือนทาง Line OA",
                "แจ้งเตือนการจองใหม่",
                "แจ้งเตือนยกเลิกการจอง",
                "แจ้งเตือนรีวิวใหม่",
                "แจ้งเตือนสินค้าเหลือน้อย",
              ].map((label, i) => (
                <div key={i} className="notify-item">
                  <span>{label}</span>
                  <label className="switch">
                    <input type="checkbox" defaultChecked={i !== 1} />
                    <span className="slider"></span>
                  </label>
                </div>
              ))}
            </div>
            <div className="actions">
              <button className="btn-save">บันทึกการเปลี่ยนแปลง</button>
            </div>
          </div>
        )}
      </section>
    </main>
  );
}
