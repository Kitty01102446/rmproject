import React, { useState } from "react";
import { FiSearch, FiEye, FiCheck, FiX, FiTrash2 } from "react-icons/fi";
import ReactDOM from "react-dom";
import "./ManageBookings.css";

export default function ManageBookings() {
  const [search, setSearch] = useState("");
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [bookings, setBookings] = useState([
    {
      id: "BK001",
      customer: "สมหญิง ใจดี",
      phone: "081-111-1111",
      service: "เพ้นท์เล็บเจล",
      employee: "วิภา ศิริมิช่วย",
      date: "27/10/2568",
      time: "10:00 น.",
      status: "ยืนยันแล้ว",
    },
    {
      id: "BK002",
      customer: "วิไล สมภพ",
      phone: "082-222-2222",
      service: "ต่อเล็บอะคริลิค",
      employee: "สุดา เส้นสวย",
      date: "27/10/2568",
      time: "11:30 น.",
      status: "รอยืนยัน",
    },
    {
      id: "BK003",
      customer: "นภา ลำดวน",
      phone: "083-333-3333",
      service: "สปามือ",
      employee: "มาลี เพิ่มศรี",
      date: "27/10/2568",
      time: "13:00 น.",
      status: "ยืนยันแล้ว",
    },
    {
      id: "BK004",
      customer: "ปรียา สังข์งาม",
      phone: "084-444-4444",
      service: "มานิคิวร์",
      employee: "วิภา ศิริมิช่วย",
      date: "26/10/2568",
      time: "14:30 น.",
      status: "เสร็จสิ้น",
    },
  ]);

  const updateStatus = (id, newStatus) => {
    setBookings((prev) =>
      prev.map((b) => (b.id === id ? { ...b, status: newStatus } : b))
    );
  };

  const deleteBooking = (id) => {
    setBookings((prev) => prev.filter((b) => b.id !== id));
  };

  const statusClass = (status) => {
    if (status === "ยืนยันแล้ว") return "status confirmed";
    if (status === "เสร็จสิ้น") return "status done";
    if (status === "ยกเลิก") return "status canceled";
    return "status pending";
  };

  return (
    <div className="admin-root">
      <main className="manage">
        <div className="header">
          <div>
            <h1>การจอง</h1>
            <p>จัดการข้อมูลการจองทั้งหมดของร้าน</p>
          </div>
        </div>

        <div className="service-card">
          <div className="toolbar">
            <div className="search-box">
              <FiSearch className="icon" />
              <input
                type="text"
                placeholder="ค้นหาการจองหรือชื่อลูกค้า..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          <table className="service-table">
            <thead>
              <tr>
                <th>หมายเลขการจอง</th>
                <th>ชื่อลูกค้า</th>
                <th>บริการ</th>
                <th>พนักงาน</th>
                <th>วันที่</th>
                <th>เวลา</th>
                <th>สถานะ</th>
                <th>การดำเนินการ</th>
              </tr>
            </thead>
            <tbody>
              {bookings
                .filter(
                  (b) =>
                    b.customer.includes(search) ||
                    b.id.toLowerCase().includes(search.toLowerCase())
                )
                .map((b) => (
                  <tr key={b.id}>
                    <td>{b.id}</td>
                    <td>{b.customer}</td>
                    <td>{b.service}</td>
                    <td>{b.employee}</td>
                    <td>{b.date}</td>
                    <td>{b.time}</td>
                    <td>
                      <span className={statusClass(b.status)}>{b.status}</span>
                    </td>
                    <td className="action-buttons">
                      <button
                        className="icon-btn view"
                        onClick={() => setSelectedBooking(b)}
                      >
                        <FiEye />
                      </button>
                      <button
                        className="icon-btn confirm"
                        onClick={() => updateStatus(b.id, "ยืนยันแล้ว")}
                      >
                        <FiCheck />
                      </button>
                      <button
                        className="icon-btn cancel"
                        onClick={() => updateStatus(b.id, "ยกเลิก")}
                      >
                        <FiX />
                      </button>
                      <button
                        className="icon-btn delete"
                        onClick={() => deleteBooking(b.id)}
                      >
                        <FiTrash2 />
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </main>

      {/* Modal รายละเอียดการจอง */}
      {selectedBooking &&
        ReactDOM.createPortal(
          <div
            className="modal-overlay"
            onClick={() => setSelectedBooking(null)}
          >
            <div className="modal booking-modal" onClick={(e) => e.stopPropagation()}>
              <h3>รายละเอียดการจอง</h3>
              <div className="booking-detail">
                <p><strong>หมายเลขการจอง:</strong> {selectedBooking.id}</p>
                <p><strong>ชื่อลูกค้า:</strong> {selectedBooking.customer}</p>
                <p><strong>เบอร์โทรศัพท์:</strong> {selectedBooking.phone}</p>
                <p><strong>บริการ:</strong> {selectedBooking.service}</p>
                <p><strong>พนักงาน:</strong> {selectedBooking.employee}</p>
                <p><strong>วันที่:</strong> {selectedBooking.date}</p>
                <p><strong>เวลา:</strong> {selectedBooking.time}</p>
                <p>
                  <strong>สถานะ:</strong>{" "}
                  <span className={statusClass(selectedBooking.status)}>
                    {selectedBooking.status}
                  </span>
                </p>
              </div>
              <div className="modal-actions">
                <button
                  onClick={() => setSelectedBooking(null)}
                  className="cancel-btn"
                >
                  ปิด
                </button>
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
}
