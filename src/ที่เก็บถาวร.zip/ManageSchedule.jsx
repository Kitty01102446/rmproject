import React, { useState } from "react";
import Calendar from "react-calendar";
import "react-calendar/dist/Calendar.css";
import "./ManageSchedule.css";

export default function ManageSchedule() {
  const [selectedDate, setSelectedDate] = useState(new Date());
  const [schedules, setSchedules] = useState({});
  const [adding, setAdding] = useState(false);
  const [newTask, setNewTask] = useState({ employee: "", time: "", task: "" });

  const employees = [
    { name: "วิภา ศิริมิช่วย", color: "#e64ba5" },
    { name: "สุดา เส้นสวย", color: "#9c8bff" },
    { name: "มาลี เพิ่มศรี", color: "#58a7ff" },
    { name: "นีร ศิโรจน์", color: "#ff9c40" },
  ];

  const handleAddSchedule = () => {
    const dateKey = selectedDate.toDateString();
    if (!newTask.employee || !newTask.time || !newTask.task) {
      alert("กรุณากรอกข้อมูลให้ครบ");
      return;
    }

    setSchedules((prev) => ({
      ...prev,
      [dateKey]: [...(prev[dateKey] || []), newTask],
    }));

    setNewTask({ employee: "", time: "", task: "" });
    setAdding(false);
  };

  const selectedKey = selectedDate.toDateString();
  const todaySchedule = schedules[selectedKey] || [];

  return (
    <div className="schedule-root">
      <div className="header">
        <div>
          <h1>ตารางงานพนักงาน</h1>
          <p>จัดการตารางงานและเวลาทำงานของพนักงาน</p>
        </div>
        <button className="btn-add" onClick={() => setAdding(true)}>
          + เพิ่มตารางงานใหม่
        </button>
      </div>

      <div className="schedule-grid">
        {/* ปฏิทิน */}
        <div className="calendar-box">
          <Calendar
            onChange={setSelectedDate}
            value={selectedDate}
            locale="th-TH"
          />
        </div>

        {/* ตารางงานในวัน */}
        <div className="day-box">
          <h3>ตารางงาน {selectedDate.toLocaleDateString("th-TH", { day: "numeric", month: "short" })}</h3>
          {todaySchedule.length === 0 ? (
            <p className="empty">ไม่มีตารางงาน</p>
          ) : (
            <ul>
              {todaySchedule.map((item, idx) => (
                <li key={idx}>
                  <span className="time">{item.time}</span>
                  <span className="task">{item.task}</span>
                  <span className="emp">{item.employee}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* รายชื่อพนักงาน */}
        <div className="emp-box">
          <h3>พนักงานที่ว่าง</h3>
          <ul>
            {employees.map((e) => (
              <li key={e.name}>
                <span className="dot" style={{ background: e.color }}></span>
                {e.name} <span className="status">ว่าง</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Modal เพิ่มตารางงาน */}
      {adding && (
        <div className="modal-overlay" onClick={() => setAdding(false)}>
          <div className="modal" onClick={(e) => e.stopPropagation()}>
            <h3>เพิ่มตารางงานใหม่</h3>

            <label>ชื่อพนักงาน</label>
            <select
              value={newTask.employee}
              onChange={(e) => setNewTask({ ...newTask, employee: e.target.value })}
            >
              <option value="">-- เลือกพนักงาน --</option>
              {employees.map((e) => (
                <option key={e.name} value={e.name}>
                  {e.name}
                </option>
              ))}
            </select>

            <label>เวลา</label>
            <input
              type="text"
              placeholder="เช่น 10:00 - 12:00"
              value={newTask.time}
              onChange={(e) => setNewTask({ ...newTask, time: e.target.value })}
            />

            <label>รายละเอียดงาน</label>
            <input
              type="text"
              placeholder="เช่น รับลูกค้า / เพ้นท์เล็บ"
              value={newTask.task}
              onChange={(e) => setNewTask({ ...newTask, task: e.target.value })}
            />

            <div className="modal-actions">
              <button onClick={() => setAdding(false)} className="cancel-btn">
                ยกเลิก
              </button>
              <button onClick={handleAddSchedule} className="save-btn">
                บันทึก
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
