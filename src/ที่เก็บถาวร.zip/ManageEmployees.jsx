import React, { useState } from "react";
import { FiEdit2, FiTrash2, FiSearch, FiDownload } from "react-icons/fi";
import ReactDOM from "react-dom";
import "./ManageEmployees.css";

export default function ManageEmployees() {
  const [search, setSearch] = useState("");
  const [employees, setEmployees] = useState([
    { id: 1, name: "วิภา ศิริมิช่วย", role: "ช่างทำเล็บ", phone: "081-234-5678", email: "wipa@email.com", start: "15/1/2566", status: "ทำงานอยู่" },
    { id: 2, name: "สุดา เส้นสวย", role: "ช่างทำผม", phone: "082-345-6789", email: "suda@email.com", start: "20/3/2566", status: "ทำงานอยู่" },
    { id: 3, name: "มาลี เพิ่มศรี", role: "ผู้ช่วย", phone: "083-456-7890", email: "malee@email.com", start: "10/6/2567", status: "ทำงานอยู่" },
    { id: 4, name: "นีภา ศิโรจน์", role: "แอดมินร้าน", phone: "084-567-8901", email: "nipa@email.com", start: "1/11/2565", status: "ทำงานอยู่" },
  ]);

  const [editing, setEditing] = useState(null);
  const [adding, setAdding] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(null);

  const handleSave = () => {
    if (adding) {
      setEmployees((prev) => [...prev, { ...editing, id: prev.length + 1 }]);
    } else {
      setEmployees((prev) =>
        prev.map((e) => (e.id === editing.id ? editing : e))
      );
    }
    setEditing(null);
    setAdding(false);
  };

  return (
    <div className="admin-root">
      <main className="manage">
        <div className="header">
          <div>
            <h1>จัดการพนักงาน</h1>
            <p>จัดการข้อมูลพนักงานทั้งหมด</p>
          </div>
          <div className="header-actions">
            <button className="btn-export">
              <FiDownload /> ส่งออก CSV
            </button>
            <button
              className="btn-add"
              onClick={() => {
                setAdding(true);
                setEditing({
                  name: "",
                  role: "",
                  phone: "",
                  email: "",
                  start: "",
                  status: "ทำงานอยู่",
                });
              }}
            >
              + เพิ่มพนักงานใหม่
            </button>
          </div>
        </div>

        <div className="service-card">
          <div className="toolbar">
            <div className="search-box">
              <FiSearch className="icon" />
              <input
                type="text"
                placeholder="ค้นหาพนักงาน..."
                value={search}
                onChange={(e) => setSearch(e.target.value)}
              />
            </div>
          </div>

          <table className="service-table">
            <thead>
              <tr>
                <th>รูปภาพ</th>
                <th>ชื่อพนักงาน</th>
                <th>ตำแหน่ง</th>
                <th>เบอร์โทรศัพท์</th>
                <th>อีเมล</th>
                <th>วันที่เริ่มงาน</th>
                <th>สถานะ</th>
                <th>การดำเนินการ</th>
              </tr>
            </thead>
            <tbody>
              {employees
                .filter((e) => e.name.includes(search))
                .map((e) => (
                  <tr key={e.id}>
                    <td>
                      <div className="avatar">{e.name[0]}</div>
                    </td>
                    <td>{e.name}</td>
                    <td>{e.role}</td>
                    <td>{e.phone}</td>
                    <td>{e.email}</td>
                    <td>{e.start}</td>
                    <td>
                      <span className="status open">{e.status}</span>
                    </td>
                    <td>
                      <button
                        className="icon-btn edit"
                        onClick={() => setEditing({ ...e })}
                      >
                        <FiEdit2 />
                      </button>
                      <button
                        className="icon-btn delete"
                        onClick={() => setConfirmDelete(e)}
                      >
                        <FiTrash2 />
                      </button>
                    </td>
                  </tr>
                ))}
            </tbody>
          </table>
        </div>
      </main>

      {/* ===== Modal แก้ไข / เพิ่ม ===== */}
      {editing &&
        ReactDOM.createPortal(
          <div className="modal-overlay" onClick={() => setEditing(null)}>
            <div className="modal" onClick={(e) => e.stopPropagation()}>
              <h3>{adding ? "เพิ่มพนักงานใหม่" : "แก้ไขข้อมูลพนักงาน"}</h3>

              <label>ชื่อพนักงาน</label>
              <input
                type="text"
                value={editing.name}
                onChange={(e) =>
                  setEditing({ ...editing, name: e.target.value })
                }
              />

              <label>ตำแหน่ง</label>
              <input
                type="text"
                value={editing.role}
                onChange={(e) =>
                  setEditing({ ...editing, role: e.target.value })
                }
              />

              <label>เบอร์โทรศัพท์</label>
              <input
                type="text"
                value={editing.phone}
                onChange={(e) =>
                  setEditing({ ...editing, phone: e.target.value })
                }
              />

              <label>อีเมล</label>
              <input
                type="email"
                value={editing.email}
                onChange={(e) =>
                  setEditing({ ...editing, email: e.target.value })
                }
              />

              <label>วันที่เริ่มงาน</label>
              <input
                type="text"
                value={editing.start}
                onChange={(e) =>
                  setEditing({ ...editing, start: e.target.value })
                }
              />

              <div className="modal-actions">
                <button onClick={() => setEditing(null)} className="cancel-btn">
                  ยกเลิก
                </button>
                <button onClick={handleSave} className="save-btn">
                  บันทึก
                </button>
              </div>
            </div>
          </div>,
          document.body
        )}

      {/* ===== Modal ยืนยันลบ ===== */}
      {confirmDelete &&
        ReactDOM.createPortal(
          <div className="modal-overlay" onClick={() => setConfirmDelete(null)}>
            <div className="modal small" onClick={(e) => e.stopPropagation()}>
              <h4>ยืนยันการลบ</h4>
              <p>ต้องการลบ “{confirmDelete.name}” หรือไม่?</p>
              <div className="modal-actions">
                <button
                  onClick={() => setConfirmDelete(null)}
                  className="cancel-btn"
                >
                  ยกเลิก
                </button>
                <button
                  onClick={() => {
                    setEmployees((prev) =>
                      prev.filter((x) => x.id !== confirmDelete.id)
                    );
                    setConfirmDelete(null);
                  }}
                  className="delete-btn"
                >
                  ลบ
                </button>
              </div>
            </div>
          </div>,
          document.body
        )}
    </div>
  );
}
